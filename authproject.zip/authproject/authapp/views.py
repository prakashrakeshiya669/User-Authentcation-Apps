from django.shortcuts import render, redirect ,get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError  

# Create your views here.
def home_view(request):
    return render(request, 'index.html')

def register_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        email = request.POST.get("email")


        if not (username  and password and email):
           messages.error(request, 'Please fill out all fields in Register Page.')
           return render(request, 'register.html')
        else:
            # Check if username is already taken
            if User.objects.filter(username=username, email=email).exists():
                messages.error(request, 'Username  and email is already taken.')
                return render(request, 'register.html')
            else:
                 user  = User.objects.create_user(username=username, password=password, email=email)
                 user.save()
                 messages.success(request, 'user create successfully!!!! please login')
        #return redirect('/login/')
    return render(request, 'register.html')


def login_view(request):
    if request.method=="POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(username=username, password=password)
        
        if user is not None:
            login(request, user)
            if request.user.is_superuser:
                return redirect('admindashboard')
            else:
               return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password')
    return render(request, 'login.html')



def logout_view(request):
    logout(request)
    return redirect('/')


def admindashboard_view(request):
    if request.user.is_superuser:
        objectss =User.objects.all()
        return render(request, 'admindashboard.html', {'user': request.user,'objectss':  objectss})
    else:
        messages.error(request, "You are not authorized to access this page")
        return redirect('login')  # Redirect to login if not authenticated


def dashboard_view(request):
    if request.user.is_authenticated:
        return render(request, 'dashboard.html', {'user': request.user})
    
    else:
        return redirect('login')  # Redirect to login if not authenticated
    

def delete_view(request):
    id = request.GET.get("id")
    d=User.objects.filter(id=id)
    d.delete()
    return redirect('admindashboard')



@login_required
def update_view(request):
        id = int(request.GET.get('id'))
        user = User.objects.filter(id=id)
        
        for i in user:
            print(i.username)
            print(i.email)
            print(i.password)

        if request.method =='POST':
            # Update fields
            username = request.POST.get('username')
            #email = request.POST.get('email')
       
            User.objects.filter(id=id).update(username=username)
            return redirect('/admindashboard/', id=id)  
    
        return render(request, 'update.html', {'user': user})

